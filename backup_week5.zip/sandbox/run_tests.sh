#!/bin/bash
set -e

echo "🚀 Running tests..."
pytest -q "$1" --json-report --json-report-file=.test_report.json || true

echo "=== PYTEST SUMMARY ==="
if [ -f .test_report.json ]; then
    passed=$(grep -o '"outcome": "passed"' .test_report.json | wc -l)
    failed=$(grep -o '"outcome": "failed"' .test_report.json | wc -l)
    total=$((passed + failed))
    echo "total: $total passed: $passed failed: $failed"
else
    echo "⚠️ No JSON report found."
fi
